import PlaygroundSupport
let page = PlaygroundPage.current
let viewController = FirstGameController()
page.liveView = viewController
